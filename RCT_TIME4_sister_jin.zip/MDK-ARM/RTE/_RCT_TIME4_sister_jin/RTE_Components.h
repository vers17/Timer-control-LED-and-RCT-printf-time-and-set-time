
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'RCT_TIME4_sister_jin' 
 * Target:  'RCT_TIME4_sister_jin' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "stm32f10x.h"



#endif /* RTE_COMPONENTS_H */
